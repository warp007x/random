import 'package:flutter/material.dart';

List<Color> colors = <Color>[
  const Color.fromRGBO(240, 232, 223, 1.0),
  const Color.fromRGBO(214, 214, 198, 1.0),
  const Color.fromRGBO(209, 205, 190, 1.0),
  const Color.fromRGBO(239, 233, 219, 1.0),
  const Color.fromRGBO(207, 203, 188, 1.0),
  const Color.fromRGBO(231, 222, 211, 1.0),
  const Color.fromRGBO(217, 214, 198, 1.0),
];
