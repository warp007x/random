class Category {
  final String catId;
  final String categoryName;
  final String imagePath;

  Category({this.catId, this.categoryName, this.imagePath});
}
