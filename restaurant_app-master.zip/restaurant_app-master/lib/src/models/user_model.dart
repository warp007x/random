// import 'package:meta/meta.dart'; //for *required

class User {
  final String id;
  final String token;
  final String email;


  User({
    this.id,
    this.token,
    this.email,
  });
}
